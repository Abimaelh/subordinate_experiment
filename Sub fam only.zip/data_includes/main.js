PennController.ResetPrefix(null); // Initiates PennController

PreloadZip( "https://vicgom14.dreamhosters.com/subordinate_stims/singular_sentence.zip"),
PreloadZip( "https://vicgom14.dreamhosters.com/subordinate_stims/plural_sentence.zip"),
PreloadZip( "https://vicgom14.dreamhosters.com/subordinate_stims/testing_images_resized.zip"),
PreloadZip( "https://vicgom14.dreamhosters.com/subordinate_stims/training_images_resized.zip"),
PreloadZip( "https://vicgom14.dreamhosters.com/subordinate_stims/threes.zip"),

Sequence("Enter_ID","Instructions","preload-exp","training","test_transition","test","final"); //back to back exemplars still possible
SetCounter("counter","inc", 1);

newTrial("Enter_ID",
    newText("ID_int", "Please enter your Prolific ID and then click the button below to start the experiment.<p> </p>")
        .print()
        .settings.center()
    ,
    newTextInput("input_ID")
        .settings.center()
        .print()
    ,
    newText("nocode", "<p></p>Please enter your Prolific ID. This is a necessary step in order for you to receive credit.").color("red").bold().center()
    ,
    newText("<p></p>")
        .print()
        .settings.center()
    ,
    newButton("NEXT")
        .settings.center()
        .callback(
            getTextInput("input_ID")
                .test.text(/[^\s]/)
                .failure(getText("nocode").print()))
        .print()
        .wait(getTextInput("input_ID").test.text(/[^\s]/))
    ,
    newVar("ID")
        .global()
        .set(getTextInput("input_ID"))
).setOption("hideProgressBar",true);

newTrial("Instructions",
    newText("Press_start_1", "Thank you for participating in our study! <p>Press Space to start.</p>").cssContainer("text-align","center").print()
        .print()
        .center()
    ,
    newKey("space1", " ")
        .wait()
    ,
    getText("Press_start_1")
        .text("In this study, you are going to learn the meanings of several words. You should think of these words as being from a language that you do not know. You will hear the words over the headphones, and see what they mean on the screen. Please pay attention, because you will be tested on the words at the end of the study.<p>Press Space to continue.</p>").cssContainer("text-align","center").print()
    ,
    newKey("space2", " ")
        .wait()
    ,
    getText("Press_start_1")
        .text("In the first section where you learn words, you do not need to do anything other than to listen and watch passively. Later, in the testing section, instructions will be provided on the screen. Please read the instructions carefully as you progress through the study. <p>Do you have any questions about the study at this point?</p><p>This is the end of instructions. You can press Space to start.</p>").cssContainer("text-align","center").print()
    ,
    newKey("space3", " ")
        .wait()    
);

CheckPreloaded( 
  "training","test"
).label( "preload-exp" );



Template("sub_list_fam.csv", row =>
    newTrial("training",
        fullscreen()
        ,
        newTimer("break", 500)
            .start()
            .wait()
        ,
        newAudio("label_audio", row.label_audio)
            .play()
        ,
        newImage("image", row.image)
            .center()
            .print()
        ,
        newTimer("img_timer", 2000)
            .start()
            .wait()
        ,
        getImage("image")
            .remove()
        ,
        getAudio("label_audio")
        .wait("first")
    )
);

const newToggleImage = (name,file) => [
    newVar(name+"-var", 1),
    newSelector(name+"-sel")
        .frame("solid 6px black")
        .callback( getVar(name+"-var").set(v=>1-v).test.is(1).success(getSelector(name+"-sel").unselect()) )
        .log()
    ,
    newImage(name, file)
        .size(200,200)
        .selector("shapes").selector(name+"-sel")
];

newTrial("test_transition",
    newText("Press_start_2", "Great! Now we would like to see what you have learned about the words.<p>Press Space to continue.</p>").cssContainer("text-align","center").print()
        .print()
        .center()
    ,
    newKey("space4", " ")
        .wait()
    ,
    getText("Press_start_2")
        .text("In the next section, we are testing what you think each word means. Each trial will consist of you hearing a word and seeing 12 pictures on the screen. Your job is to select all the pictures that matched the meaning of that word.<p>Press Space to continue.</p>").cssContainer("text-align","center").print()
    ,
    newKey("space5", " ")
        .wait()
    ,
    getText("Press_start_2")
        .text("Please understand that you can select more than one picture, and we encourage you to choose more than one. After you select a picture, a black box will appear around it to indicate your selection.<p>Press Space to continue.</p>").cssContainer("text-align","center").print()
    ,
    newKey("space6", " ")
        .wait()  
);

Template("sub_list_test_v4.csv", row =>
    newTrial("test", row.group,
    newAudio("test_audio",row.test_audio)
        .play()
    ,
    newText("test_words", "Please click on everything that is a " + row.test_words + "<p> </p>")
        .print()
        .center()
    ,
    newSelector("shapes").disable(),
        newToggleImage("test_img_1", row.test_img_1)
    ,
        newToggleImage("test_img_2", row.test_img_2)
    ,
        newToggleImage("test_img_3", row.test_img_3)
    ,
        newToggleImage("test_img_4", row.test_img_4)
    ,
        newToggleImage("test_img_5", row.test_img_5)
    ,
        newToggleImage("test_img_6", row.test_img_6)
    ,
        newToggleImage("test_img_7", row.test_img_7)
    ,
        newToggleImage("test_img_8", row.test_img_8)
    ,
        newToggleImage("test_img_9", row.test_img_9)
    ,
        newToggleImage("test_img_10", row.test_img_10)
    ,
        newToggleImage("test_img_11", row.test_img_11)
    ,
        newToggleImage("test_img_12", row.test_img_12)
    ,
    newCanvas(1000, 723)
        .add( 40, 20, getImage("test_img_1"), 0 )
        .add( 270, 20, getImage("test_img_2"), 1 )
        .add( 500, 20, getImage("test_img_3"), 2 )
        .add( 730, 20, getImage("test_img_4"), 3 )
        .add( 40, 250, getImage("test_img_5"), 4 )
        .add( 270, 250, getImage("test_img_6"), 5 )
        .add( 500, 250, getImage("test_img_7"), 6 )
        .add( 730, 250, getImage("test_img_8"), 7 )
        .add( 40, 480, getImage("test_img_9"), 8 )
        .add( 270, 480, getImage("test_img_10"), 9 )
        .add( 500, 480, getImage("test_img_11"), 10 )
        .add( 730,480, getImage("test_img_12"), 11)
        .center()
        .settings.css("border", "solid 15px #964B00")
        .settings.css("padding", "5px")        
        .print()
    ,
    getSelector("shapes").shuffle()
    ,
    newText("<p></p>")
        .print()
        .settings.center()
    ,
    newButton("Confirm")
        .print()
        .center()
        .wait()
    ,
    getAudio("test_audio")
        .wait("first")
    )
    .log("ID",getVar("ID"))
    .log("Group",row.group)
    .log("Trial",row.trial)
    .log("test_audio",row.test_audio)
    .log("test_word",row.test_words)
);

newTrial( "final" ,
    newText("<p>Thank you for your participation!</p><p><a href='https://app.prolific.co/submissions/complete?cc=6CD41C22'>Click here to confirm your participation on Prolific.</a></p> <p>This is a necessary step in order for you to receive credit!</p>")
        .center()
        .print()
    ,
newButton("void")
    .wait()
);